package com.team3.DogCare.PetService.Domain.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WeightDto {

    private Long petId;

    private String weight;
}
