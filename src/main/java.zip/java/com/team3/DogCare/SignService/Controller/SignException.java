package com.team3.DogCare.SignService.Controller;

public class SignException extends RuntimeException {
    public SignException(String message) {
        super(message);
    }
}