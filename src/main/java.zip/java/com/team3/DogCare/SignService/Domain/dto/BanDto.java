package com.team3.DogCare.SignService.Domain.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BanDto {
    private long id;
    private long bantime;
}
