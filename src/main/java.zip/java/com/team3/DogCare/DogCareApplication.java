package com.team3.DogCare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DogCareApplication {

	public static void main(String[] args) {
		SpringApplication.run(DogCareApplication.class, args);
	}

}
